BOLT_API_KEY = "9d15b199-fd41-47cf-8b2b-6a863e8da6b5" #This is your Bolt cloud>

DEVICE_ID = "BOLT13134086" #This is the ID number of yo.

TELEGRAM_CHAT_ID = "@noisebot1" #This is the channel ID of the


TELEGRAM_BOT_ID = "bot5267570081:AAF864ojmMGW8j43tqYsbHu7kbWbvEG9MyM" #This is >


THRESHOLD = 80 #Threshold beyond which the
