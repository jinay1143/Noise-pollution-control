
import requests 
import json
import time
from boltiot import Bolt
import configuration
mybolt = Bolt(configuration.BOLT_API_KEY,configuration.DEVICE_ID)

def get_sound_sensor_value_from_pin(5V):
    try:
        response = mybolt.analogRead(A0)
        data = json.loads(response)
        if data["success"] != 1:
                    print("Request not successful")
                    print("This is the response->", data)
                    return -999
                    sound_sensor_value = int(data["value"])
        return sound_sensor_value
            	
    except Exception as e:
        print("Something went wrong when returning the sensor value")
        print(e)
     	
    return -999
    
def send_telegram_message(message):
    url = "https://api.telegram.org/" + configuration.TELEGRAM_BOT_ID + "/sendMessage"
    data = {
            "chat_id": configuration.TELEGRAM_CHAT_ID,
            "text": message
        }
    try:
        response = requests.request(
            "GET",
            url,
            params = data
        )
        print("This is the Telegram response")
        print(response.text)
        telegram_data = json.loads(response.text)
        return telegram_data["OK"]
    except Exception as e:
        print("An error occurred in sending the alert message via Telegram")
        print(e)
    return False
    
    
while True:
    #Step 1
    sound_sensor_value = get_sound_sensor_value_from_pin("A0")    
    print("The current sensor reading is:", sound_sensor_value)
    #Step 2
    if sound_sensor_value == -999:
	    print("Request was unsuccessful. Skipping.")
    time.sleep(10)
    continue
    #Step 3
    if sound_sensor_value >= configuration.THRESHOLD:
        print("Sensor value has exceeded threshold")
        message = "Alert! Noise disturbance around the XYZ Hospital. Random and unidentified sound intensity has crossed " + str(configuration.THRESHOLD) + str("dB") + "The current sound sensor reading is " + str(sound_sensor_value) + str("dB") + str("To, The Police Incharge, Immediate action required. Thankyou.")
        telegram_status = send_telegram_message(message)
        print("This is the Telegram status:", telegram_status)
        
    # Step 4
    time.sleep(50)	#Time interval to get the status update.
