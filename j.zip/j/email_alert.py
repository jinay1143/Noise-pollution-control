import smtplib
import mimetypes
from email.message import EmailMessage
message2=EmailMessage()
sender = "jdnoisebot@gmail.com"
recipient = "jinay.j@somaiya.edu"
sender_pass="@Password123"
message2['From'] = sender
message2['To'] = recipient
message2['Subject'] = 'alert'
body = 'alert noise pollution'
message2.set_content(body)
mime_type, _ = mimetypes.guess_type('alert.txt')
mime_type, mime_subtype = mime_type.split('/')
with open('alert.txt', 'rb') as file:
    message2.add_attachment(file.read(),maintype=mime_type,subtype=mime_subtype,filename='alert.txt')
    mail_server = smtplib.SMTP_SSL('smtp.gmail.com')
    mail_server.set_debuglevel(1)
    mail_server.login(sender, sender_pass) 
    mail_server.send_message(message2)
    mail_server.quit()